'''Ejercicio 13: Escribir un programa que muestre el eco de todo lo que el usuario introduzca hasta que el usuario escriba “salir” que terminará.'''
# definicion de la funcion
def crear_frase(frase):
    crearfrase="adios"
    if frase=='adios':
        return crearfrase
    elif frase=='':
        return crearfrase
    else:
        while (frase not in ["","adios"]):
            repetirfrase=input("escribe algo: ")
            if repetirfrase=='adios':
                return crearfrase
            elif repetirfrase=='':
                return crearfrase

if __name__=="__main__":
    # entrada
    frase=input("escribe algo: ")
    # procesamiento
    crearfrase=crear_frase(frase)
    # salida
    print(crearfrase)
