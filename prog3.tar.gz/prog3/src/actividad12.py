'''Ejercicio 12: Escribir un programa en el que se pregunte al usuario por una frase y una letra, y muestre por pantalla el número de veces que aparece la letra en la frase.'''
#definicion de la funcion
def numero_letra(frase, letra):
    contador = 0
    for veces in frase:
        if veces == letra:
            contador += 1
            mensaje="la letra " + "'"+letra+"'" + " aparece " + str(contador)+ " veces"
    return mensaje

if __name__ == "__main__":
    # Entrada
    frase = input("Introduce una frase: ")
    letra = input("Introduce una letra: ")
    #procesamiento
    mensaje = numero_letra(frase,letra)
    # Salida
    print(mensaje)