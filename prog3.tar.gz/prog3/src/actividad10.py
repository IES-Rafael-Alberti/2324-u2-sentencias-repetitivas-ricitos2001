'''Ejercicio 10: Escribir un programa que pida al usuario un número entero y muestre por pantalla si es un número primo o no.'''
#definicion de la funcion
def indicar_primo(numero):
    x=1
    c=0
    while x <=numero:
        if numero % x == 0:
            c=c +1
        x=x+1
    if c==2:
        primo="el numero es primo"
    else: 
        primo="el numero no es primo"
    return primo
if __name__=="__main__":
    # Entrada
    numero = int(input("introduce un numero: "))
    # Procesamiento
    primo=indicar_primo(numero)
    # Salida
    print(primo)
