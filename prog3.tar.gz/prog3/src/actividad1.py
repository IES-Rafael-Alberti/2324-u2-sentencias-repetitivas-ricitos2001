'''Ejercicio 1: Escribir un programa que pida al usuario una palabra y la muestre por pantalla 10 veces.'''
# definicion de la funcion
def crear_repeticiones(nombre,numero):
    repeticiones =""
    if numero > 0:
        for contador in range(numero):
            repeticiones += nombre + "\n"
    return repeticiones

if __name__ == "__main__": 
    # entrada
    nombre = input("escriba su nombre: ")
    # procesamiento
    numero = 10
    repeticiones = crear_repeticiones(nombre,numero)
    # salida
    print(repeticiones)