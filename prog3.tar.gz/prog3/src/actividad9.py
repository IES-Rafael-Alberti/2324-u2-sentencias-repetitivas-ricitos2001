'''Ejercicio 9: Escribir un programa que almacene la cadena de caracteres contraseña en una variable, pregunte al usuario por la contraseña hasta que introduzca la contraseña correcta.'''
# definicon de la funcion
def verificar_contraseña(contraseñausuario):
    contraseña="usuario"
    mensaje="contraseña correcta"
    if contraseñausuario==contraseña:
        return mensaje
    else:
        while (contraseñausuario not in [contraseña]):
            repetircontraseña=input("contraseña incorrecta, intentalo de nuevo: ")
            if repetircontraseña==contraseña:
                return mensaje

if __name__ == "__main__":
    # Entrada
    contraseñausuario = input("Introduce la contraseña: ")
    # procesamiento
    mensaje=verificar_contraseña(contraseñausuario)
    # salida
    print(mensaje)
    
