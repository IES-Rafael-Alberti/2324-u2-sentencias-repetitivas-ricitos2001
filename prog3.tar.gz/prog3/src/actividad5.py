'''Ejercicio 5: Escribir un programa que pregunte al usuario una cantidad a invertir, el interés anual y el número de años, y muestre por pantalla el capital obtenido en la inversión cada año que dura la inversión.'''
# definicion de la funcion
def calcular_inversion(cantidad, interes, años):
    resultado = ""
    for año in range(1, años + 1):
        resultado="la cantidad es de "+str(cantidad * año + (interes / 100))+"€"
    return resultado

if __name__ == "__main__":
    # entrada
    cantidad = float(input("cantidad a invertir: "))
    interes = float(input("interes anual en porcentaje: "))
    años = int(input("numero de años: "))
    # procesamiento
    resultado = calcular_inversion(cantidad, interes, años)
    # salida
    print(resultado)