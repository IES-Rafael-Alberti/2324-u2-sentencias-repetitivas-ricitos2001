'''Ejercicio 8: Escribir un programa que pida al usuario un número entero y muestre por pantalla un triángulo rectángulo como el de más abajo.
1
3 1
5 3 1
7 5 3 1
9 7 5 3 1'''

# definicion de la variable
def crear_triangulo(numero):
    triangulo = ""
    if numero >= 0:
        for i in range(1, numero + 1, 2):
            for numero2 in range(i, 0, -2):
                triangulo += str(numero2)+" "
            triangulo += "\n"
        return triangulo

if __name__ == "__main__":
    # entrada
    numero = int(input("escribe un numero: "))
    # procesamiento
    triangulo=crear_triangulo(numero)
    # salida
    print(triangulo)
