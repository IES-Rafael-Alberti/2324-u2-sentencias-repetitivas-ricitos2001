'''Ejercicio 11: Escribir un programa que pida al usuario una palabra y luego muestre por pantalla una a una las letras de la palabra introducida empezando por la última.'''
# definicion de la funcion
def crear_inversion(palabra):
    while not (palabra and palabra.isalpha()):
        palabra = input("escribe una palabra: ")
    palabrainvertida = ""
    for letra in range(len(palabra) - 1, -1, -1):
        palabrainvertida += palabra[letra]
    return palabrainvertida

if __name__ == "__main__":
    # Entrada
    palabra = input("escribe una palabra: ")
    # Proceso
    palabrainvertida = crear_inversion(palabra)
    # Salida
    print(palabrainvertida)