'''Ejercicio 4: Escribir un programa que pida al usuario un número entero positivo y muestre por pantalla la cuenta atrás desde ese número hasta cero separados por comas.'''
# definicion de la funcion
def crear_lista(numero):
    lista = ""
    if numero > 0:
        for i in range(numero+1):
            lista += str(numero-i)
            if i < numero:
                lista += ", "
        return lista
if __name__=="__main__":
    # entrada
    numero = int(input("introduce un numero: "))
    # procesamiento
    lista=crear_lista(numero)
    # salida
    print(lista)
