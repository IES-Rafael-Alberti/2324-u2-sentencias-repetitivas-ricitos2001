'''Ejercicio 6: Escribir un programa que pida al usuario un número entero y muestre por pantalla un triángulo rectángulo como el de más abajo, de altura el número introducido.
*
**
***
****
*****'''
# definicion de la funcion
def crear_triangulo(numero):
    triangulo = ""
    if numero >= 0:
        for asterisco in range(1, numero + 1):
            triangulo += "*" * asterisco + "\n"
        return triangulo

if __name__ == "__main__":
    # entrada
    numero = int(input("escribe un numero: "))
    # procesamiento 
    triangulo = crear_triangulo(numero)
    # salida
    print(triangulo)