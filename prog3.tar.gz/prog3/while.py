if __name__=="__main__":
    contraseñausuario=input("introduce la contraseña: ")
    contraseña="usuario"
    mensaje="contraseña correcta"
    if contraseñausuario==contraseña:
        print (mensaje)
    else:
        while (contraseñausuario not in ["usuario"]):
            contraseñausuario=input("introduce la contraseña: ")
            if contraseñausuario==contraseña:
                print (mensaje)
