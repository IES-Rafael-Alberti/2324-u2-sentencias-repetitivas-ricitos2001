import pytest
from src.actividad6 import crear_triangulo
@pytest.mark.parametrize(
    "numero, triangulo",
    [
        (1,"*\n"),
        (2,"*\n**\n"),
        (3,"*\n**\n***\n"),
        (4,"*\n**\n***\n****\n"),
        (5,"*\n**\n***\n****\n*****\n")
    ]
)
def test_crear_triangulo_params(numero,triangulo):
    assert crear_triangulo(numero) == triangulo
    assert crear_triangulo(numero) == triangulo
    assert crear_triangulo(numero) == triangulo
    assert crear_triangulo(numero) == triangulo
    assert crear_triangulo(numero) == triangulo