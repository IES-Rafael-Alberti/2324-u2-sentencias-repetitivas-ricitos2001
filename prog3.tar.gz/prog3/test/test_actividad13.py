import pytest
from src.actividad13 import crear_frase
@pytest.mark.parametrize(
    "frase",
    [
        ("adios")
    ]  
)
def test_crear_frase_params(frase):
    assert crear_frase(frase)
