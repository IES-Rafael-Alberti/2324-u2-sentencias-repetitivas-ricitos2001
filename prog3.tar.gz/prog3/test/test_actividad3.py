import pytest
from src.actividad3 import crear_impares
@pytest.mark.parametrize(
    "numero, impares",
    [
        (21,"1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21")
    ]  
)
def test_crear_impares_params(numero, impares):
    assert crear_impares(numero) == impares