import pytest
from src.actividad12 import numero_letra
@pytest.mark.parametrize(
    "frase, letra, mensaje",
    [
        ("hola mundo","o","la letra 'o' aparece 2 veces")
    ]
)
def test_numero_letra_params(frase,letra,mensaje):
    assert numero_letra(frase,letra) == mensaje
