import pytest
from src.actividad10 import indicar_primo
@pytest.mark.parametrize(
    "numero,primo",
    [
        (2,"el numero es primo"),
        (9,"el numero no es primo")
    ]  
)
def test_indicar_primo_params(numero,primo):
    assert indicar_primo(numero,) == primo