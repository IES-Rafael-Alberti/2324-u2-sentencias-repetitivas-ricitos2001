import pytest
from src.actividad5 import calcular_inversion
@pytest.mark.parametrize(
        "cantidad, interes,años,resultado",
        [
            (1000,100,2,"la cantidad es de 2001.0€")

        ]
)
def test_calcular_inversion_params(cantidad,interes,años,resultado):
    assert calcular_inversion(cantidad,interes,años)==resultado