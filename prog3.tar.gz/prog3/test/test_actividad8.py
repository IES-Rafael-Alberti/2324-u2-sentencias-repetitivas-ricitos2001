import pytest
from src.actividad8 import crear_triangulo
@pytest.mark.parametrize(
    "numero, triangulo",
    [
        (1,"1 \n"),
        (2,"1 \n"),
        (3,"1 \n3 1 \n"),
        (4,"1 \n3 1 \n"),
        (5,"1 \n3 1 \n5 3 1 \n"),
        (6,"1 \n3 1 \n5 3 1 \n"),
        (7,"1 \n3 1 \n5 3 1 \n7 5 3 1 \n"),
        (8,"1 \n3 1 \n5 3 1 \n7 5 3 1 \n"),
        (9,"1 \n3 1 \n5 3 1 \n7 5 3 1 \n9 7 5 3 1 \n"),
        (10,"1 \n3 1 \n5 3 1 \n7 5 3 1 \n9 7 5 3 1 \n")


    ]
)
def test_crear_triangulo_params(numero,triangulo):
    assert crear_triangulo(numero) == triangulo
    assert crear_triangulo(numero) == triangulo
    assert crear_triangulo(numero) == triangulo
    assert crear_triangulo(numero) == triangulo