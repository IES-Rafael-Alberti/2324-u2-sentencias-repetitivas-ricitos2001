import pytest
from src.actividad11 import crear_inversion
@pytest.mark.parametrize(
    "palabra, palabrainvertida",
    [
        ("hola","aloh")
    ]  
)
def test_crear_inversion_params(palabra,palabrainvertida):
    assert crear_inversion(palabra) == palabrainvertida