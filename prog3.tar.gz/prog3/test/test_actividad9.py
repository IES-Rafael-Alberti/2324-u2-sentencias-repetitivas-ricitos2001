import pytest
from src.actividad9 import verificar_contraseña
from src.actividad9 import verificar_contraseña
@pytest.mark.parametrize(
    "contraseñausuario, repetircontraseña",
    [
        ("us", "contraseña incorrecta, intentalo de nuevo: ")

    ]      
)
def test_verificar_contraseña_params(contraseñausuario,repetircontraseña):
    assert verificar_contraseña(contraseñausuario) == repetircontraseña
@pytest.mark.parametrize(
    "contraseñausuario, mensaje",
    [
        ("usuario", "contraseña correcta")

    ]
)
def test_verificar_contraseña_params(contraseñausuario,mensaje):
    assert verificar_contraseña(contraseñausuario) == mensaje
